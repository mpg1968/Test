﻿using System;
using System.Configuration;

namespace OnlineBookStore.Helpers
{
    public static class AppConfigHelper
    {
        /// <summary>
        /// Using the Key. Fetches the connection string from the app.config
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetConnectionString(string key)
        {
            try
            {
                var connectionSetting = ConfigurationManager.ConnectionStrings[key].ConnectionString;
                return connectionSetting;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
    }
}
