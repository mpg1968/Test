namespace OnlineBookStore.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class OrderDetails : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.OrderDetails", "BookOrder_Id", "dbo.BookOrders");
            DropIndex("dbo.OrderDetails", new[] { "BookOrder_Id" });
            RenameColumn(table: "dbo.OrderDetails", name: "BookOrder_Id", newName: "BookOrderId");
            AlterColumn("dbo.OrderDetails", "BookOrderId", c => c.Int(nullable: false));
            CreateIndex("dbo.OrderDetails", "BookOrderId");
            AddForeignKey("dbo.OrderDetails", "BookOrderId", "dbo.BookOrders", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.OrderDetails", "BookOrderId", "dbo.BookOrders");
            DropIndex("dbo.OrderDetails", new[] { "BookOrderId" });
            AlterColumn("dbo.OrderDetails", "BookOrderId", c => c.Int());
            RenameColumn(table: "dbo.OrderDetails", name: "BookOrderId", newName: "BookOrder_Id");
            CreateIndex("dbo.OrderDetails", "BookOrder_Id");
            AddForeignKey("dbo.OrderDetails", "BookOrder_Id", "dbo.BookOrders", "Id");
        }
    }
}
