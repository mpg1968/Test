namespace OnlineBookStore.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BookCategoryDiscounts",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CategoryType = c.Int(nullable: false),
                        CreateDateTime = c.DateTime(nullable: false),
                        Discount = c.Decimal(nullable: false, precision: 18, scale: 2),
                        StartDate = c.DateTime(nullable: false),
                        EndDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.BookOrders",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        OrderNumber = c.Int(nullable: false),
                        OrderDate = c.DateTime(nullable: false),
                        SalesTotal = c.Decimal(nullable: false, precision: 18, scale: 2),
                        SalesTaxRate = c.Decimal(nullable: false, precision: 18, scale: 2),
                        CreateDateTime = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.OrderDetails",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        BookId = c.Int(nullable: false),
                        OrderNumber = c.Int(nullable: false),
                        CategoryDiscountPercentage = c.Decimal(nullable: false, precision: 18, scale: 2),
                        DiscountValue = c.Decimal(nullable: false, precision: 18, scale: 2),
                        FinalSellPrice = c.Decimal(nullable: false, precision: 18, scale: 2),
                        CreateDateTime = c.DateTime(nullable: false),
                        BookOrder_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Books", t => t.BookId, cascadeDelete: true)
                .ForeignKey("dbo.BookOrders", t => t.BookOrder_Id)
                .Index(t => t.BookId)
                .Index(t => t.BookOrder_Id);
            
            CreateTable(
                "dbo.Books",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 255),
                        CategoryType = c.Int(nullable: false),
                        Cost = c.Decimal(nullable: false, precision: 18, scale: 2),
                        CreateDateTime = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.OrderDetails", "BookOrder_Id", "dbo.BookOrders");
            DropForeignKey("dbo.OrderDetails", "BookId", "dbo.Books");
            DropIndex("dbo.OrderDetails", new[] { "BookOrder_Id" });
            DropIndex("dbo.OrderDetails", new[] { "BookId" });
            DropTable("dbo.Books");
            DropTable("dbo.OrderDetails");
            DropTable("dbo.BookOrders");
            DropTable("dbo.BookCategoryDiscounts");
        }
    }
}
