namespace OnlineBookStore.Migrations
{
    using Models;
    using System;
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<BookStoreContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(BookStoreContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //


            //Order details
            context.OrderDetails.AddOrUpdate(
                 o => o.Id,
                 new OrderDetail
                 {
                     Id = 1,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 1,
                     CategoryDiscountPercentage = 0.05m,
                     DiscountValue = 0.549m,
                     FinalSellPrice = 10.44m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 2,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 2,
                     CategoryDiscountPercentage = 0m,
                     DiscountValue = 0m,
                     FinalSellPrice = 2.40m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 3,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 3,
                     CategoryDiscountPercentage = 0m,
                     DiscountValue = 0m,
                     FinalSellPrice = 6.80m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 4,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 4,
                     CategoryDiscountPercentage = 0.05m,
                     DiscountValue = 0.80m,
                     FinalSellPrice = 15.20m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 5,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 5,
                     CategoryDiscountPercentage = 0m,
                     DiscountValue = 0m,
                     FinalSellPrice = 22.90m,
                     CreateDateTime = DateTime.Now
                 }

                );

            //Books
            context.Books.AddOrUpdate(
                b => b.Id,
                 new Book
                 {
                     BookCategoryId = 1,
                     Cost = 10.99m,
                     Id = 1,
                     Name = "Unsolved crimes",
                     CreateDateTime = DateTime.Now
                 },
                 new Book
                 {
                     BookCategoryId = 2,
                     Cost = 2.40m,
                     Id = 2,
                     Name = "A Little Love Story",
                     CreateDateTime = DateTime.Now
                 },
                 new Book
                 {
                     BookCategoryId = 3,
                     Cost = 6.80m,
                     Id = 3,
                     Name = "Heresy",
                     CreateDateTime = DateTime.Now
                 },
                 new Book
                 {
                     BookCategoryId = 1,
                     Cost = 16.00m,
                     Id = 4,
                     Name = "Jack the Ripper",
                     CreateDateTime = DateTime.Now
                 },
                 new Book
                 {
                     BookCategoryId = 3,
                     Cost = 22.90m,
                     Id = 5,
                     Name = "The Tolkien Years",
                     CreateDateTime = DateTime.Now
                 }
                );

            // bookCategoryDiscounts
            context.BookCategoryDiscounts.AddOrUpdate(
                c => c.Id,
                new BookCategoryDiscount
                {
                    Id = 1,
                    CategoryType = 1,
                    StartDate = DateTime.Now.AddMonths(-1),
                    EndDate = DateTime.Now.AddMonths(2),
                    Discount = 0.05m,
                    CreateDateTime = DateTime.Now
                },
                new BookCategoryDiscount
                {
                    Id = 2,
                    CategoryType = 3,
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now.AddMonths(-2),
                    Discount = 0m,
                    CreateDateTime = DateTime.Now
                },

                new BookCategoryDiscount
                {
                    Id = 3,
                    CategoryType = 2,
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now.AddMonths(-2),
                    Discount = 0m,
                    CreateDateTime = DateTime.Now
                }
              );

            //Book Orders
            context.BookOrders.AddOrUpdate(
                b => b.Id,
                new BookOrder { Id = 1, OrderNumber = 1, CreateDateTime = DateTime.Now, OrderDate = DateTime.Now }
                );

            // Book Categories
            context.BookCategories.AddOrUpdate(
                c => c.Id,
                new BookCategory
                {
                    Id = 1,
                    CategoryDescription = "Crime",
                    CreateDateTime = DateTime.Now.AddDays(-2)
                },
                new BookCategory
                {
                    Id = 2,
                    CategoryDescription = "Romance",
                    CreateDateTime = DateTime.Now.AddDays(-2)
                },
                new BookCategory
                {
                    Id = 3,
                    CategoryDescription = "Fantasy",
                    CreateDateTime = DateTime.Now.AddDays(-2)
                }
                );

            // Sales Tax Rate Configutaion
            context.SalesTaxConfigurations.AddOrUpdate(
                c => c.Id,
                  new SalesTaxConfiguration
                  {
                      Id = 1,
                      SalesTaxRate = 0.10m,
                      Startdate = new DateTime(2000, 01, 01),
                      EndDate = new DateTime(2030, 01, 01),
                      CreateDateTime = DateTime.Now
                  }
                );
        }
    }
}
