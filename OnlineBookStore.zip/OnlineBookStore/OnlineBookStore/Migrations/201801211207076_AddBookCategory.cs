namespace OnlineBookStore.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddBookCategory : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BookCategories",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CategoryDescription = c.String(nullable: false, maxLength: 255),
                        CreateDateTime = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.Books", "BookCategoryId", c => c.Int(nullable: false));
            CreateIndex("dbo.Books", "BookCategoryId");
            AddForeignKey("dbo.Books", "BookCategoryId", "dbo.BookCategories", "Id", cascadeDelete: true);
            DropColumn("dbo.Books", "CategoryType");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Books", "CategoryType", c => c.Int(nullable: false));
            DropForeignKey("dbo.Books", "BookCategoryId", "dbo.BookCategories");
            DropIndex("dbo.Books", new[] { "BookCategoryId" });
            DropColumn("dbo.Books", "BookCategoryId");
            DropTable("dbo.BookCategories");
        }
    }
}
