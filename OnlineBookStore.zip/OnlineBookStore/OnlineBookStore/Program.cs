﻿using OnlineBookStore.Models;
using OnlineBookStore.Services.LogicService;
using System;
using System.Collections.Generic;
using Unity;

namespace OnlineBookStore
{
    class Program
    {
        private static IBookOrderLogicService _bookOrderService;
        private static bool _includeSalesTax;

        static void Main(string[] args)
        {
            try
            {


                // Configures DI
                ConfigureServices.Start();

                _bookOrderService = ConfigureServices.Container.Resolve<IBookOrderLogicService>();

                if (_bookOrderService == null)
                {
                    Console.WriteLine(@"Unable to reach search service. Please restart..");
                    return;
                }

                RunBookStoreApplication();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }

        /// <summary>
        /// Starts application process
        /// </summary>
        private static void RunBookStoreApplication()
        {
            var orderNumber = GetOrderNumberFromConsole();
            _includeSalesTax = GetSalesTaxResponseFromConsole();

            while (true)
            {
                var bookOrder = GetBookOrderByOrderNumber(orderNumber, _includeSalesTax);

                if (bookOrder != null)
                {
                    DisplayOrderDetails(bookOrder);
                    break;
                }

                Console.WriteLine(@"No order found, do you wish to search again? Y or N");
                var searchAgain = Console.ReadLine();

                if (string.Equals(searchAgain, "Y", StringComparison.OrdinalIgnoreCase))
                {
                    orderNumber = GetOrderNumberFromConsole();
                }
                else
                {
                    return;
                }

            }

        }

        /// <summary>
        /// Fetches the user reponse in relation to sales tax
        /// </summary>
        /// <returns>bool</returns>
        private static bool GetSalesTaxResponseFromConsole()
        {
            Console.WriteLine(@"Do you wish to have Sales Tax Calculate and Displayed?");
            var taxResponse = Console.ReadLine();

            return string.Equals(taxResponse, "Y", StringComparison.OrdinalIgnoreCase);

        }

        /// <summary>
        /// Inokes the BookOrderLogicService.GetBookOrderByOrderNumber method
        /// </summary>
        /// <param name="orderNumber">int representing the order number</param>
        /// <param name="includeSalesTax">bool - include sales tax</param>
        /// <returns></returns>
        private static BookOrder GetBookOrderByOrderNumber(int orderNumber, bool includeSalesTax = true)
        {
            return _bookOrderService.GetBookOrderByOrderNumber(orderNumber, includeSalesTax);
        }

        /// <summary>
        /// Fetches the user response in relation to the order number
        /// </summary>
        /// <returns>an order number</returns>
        private static int GetOrderNumberFromConsole()
        {
            int orderNumber;
            Console.WriteLine(@"Please enter a valid order number. Number 1, could work :-)");

            var orderNumberConsole = Console.ReadLine();

            while (true)
            {
                if (!int.TryParse(orderNumberConsole, out orderNumber))
                {
                    Console.WriteLine(@"Please enter a valid number.");
                    orderNumberConsole = Console.ReadLine();
                }
                else
                {
                    break;
                }
            }

            return orderNumber;
        }

        /// <summary>
        ///  The BookOrder response object is formatted and displayed to the console
        /// </summary>
        /// <param name="order">A BookOrder object</param>
        private static void DisplayOrderDetails(BookOrder order)
        {
            // Display order summary in console
            DisplayOrderSummary(order);

            Console.WriteLine(@"Do you wish to see the order details? Y or N");
            var detailResponse = Console.ReadLine();

            if (string.Equals(detailResponse, "Y", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("");
                DisplayOrderLines(order.OrderDetails);
            }

            Console.WriteLine(@"Press any key to exit");
            Console.Read();
        }

        /// <summary>
        /// A List of OrderDetail objects are formatted and displayed to the console
        /// </summary>
        /// <param name="orderDetails"></param>
        private static void DisplayOrderLines(List<OrderDetail> orderDetails)
        {
            Console.WriteLine(@"Order Line Details:");
            Console.WriteLine("");

            foreach (var orderDetail in orderDetails)
            {
                DisplayOrderDetailLine(orderDetail);
                Console.WriteLine("");
            }
        }

        /// <summary>
        /// An OrderDetail is formatted and displayed to the console
        /// </summary>
        /// <param name="orderDetail"></param>
        private static void DisplayOrderDetailLine(OrderDetail orderDetail)
        {
            var book = orderDetail.Book;
            var discountPercentage = orderDetail.CategoryDiscountPercentage;
            var discountValue = orderDetail.DiscountValue;
            var finalSellPrice = orderDetail.FinalSellPrice;

            DisplayBookDetails(book);

            Console.WriteLine("");
            Console.WriteLine(
                $@"Sales Discount = {discountPercentage}, Deduction = {discountValue}, Final Sell Price = {finalSellPrice}");

        }

        /// <summary>
        /// A Book object is formatted and displayed to the console
        /// </summary>
        /// <param name="book"></param>
        private static void DisplayBookDetails(Book book)
        {
            var productId = book.Id;
            var name = book.Name;
            var category = book.BookCategory.CategoryDescription;
            var cost = book.Cost;

            Console.WriteLine($@"Product Id: = {productId}");
            Console.WriteLine($@"Book Title:  = {name}");
            Console.WriteLine($@"Category: = {category}");
            Console.WriteLine($@"Unit Price: = {cost}");

        }

        /// <summary>
        /// The BookOrder object is summarised and displayed to the console
        /// </summary>
        /// <param name="order"></param>
        private static void DisplayOrderSummary(BookOrder order)
        {
            var orderNumber = order.OrderNumber.ToString();
            var salesValue = order.SalesTotal;
            var totalSalesValue = order.TotalCost;
            var salesTaxRate = order.SalesTaxRate;
            var totalSalesTaxValue = order.TotalSalesTax;

            Console.WriteLine("");
            Console.WriteLine(@"Order Summary:");
            Console.WriteLine("");
            Console.WriteLine($@"Order Number = {orderNumber}");

            if (_includeSalesTax)
            {
                Console.WriteLine(
                    $@"Sales Value (Exl Tax) = {salesValue}, Tax Rate = {salesTaxRate}, Tax Value = {
                            totalSalesTaxValue
                        }, Order Total = {totalSalesValue}");
            }
            else
            {
                Console.WriteLine($@"Sales Value (Exl Tax) = {salesValue}");
            }

        }
    }
}