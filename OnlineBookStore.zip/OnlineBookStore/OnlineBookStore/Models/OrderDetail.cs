﻿using OnlineBookStore.Repository.Interface;
using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Models
{
    public class OrderDetail : IEntity
    {
        [Required]
        public int Id { get; set; }

        public int BookOrderId { get; set; }

        public virtual Book Book { get; set; }

        public int BookId { get; set; }

        public int OrderNumber { get; set; }

        public decimal CategoryDiscountPercentage { get; set; }

        public decimal DiscountValue { get; set; }

        public decimal FinalSellPrice { get; set; }

        public DateTime CreateDateTime { get; set; }

    }
}
