﻿using OnlineBookStore.Repository.Interface;
using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Models
{
    public class BookCategory : IEntity
    {
        [Required]
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public string CategoryDescription { get; set; }

        public DateTime CreateDateTime { get; set; }
    }
}
