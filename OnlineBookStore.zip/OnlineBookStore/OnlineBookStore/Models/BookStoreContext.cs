﻿using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;

namespace OnlineBookStore.Models
{
    public class BookStoreContext : DbContext
    {
        public BookStoreContext()
            : base(Helpers.AppConfigHelper.GetConnectionString("DefaultConnection"))
        {

        }

        public static BookStoreContext Create()
        {
            return new BookStoreContext();
        }

        public DbSet<Book> Books { get; set; }

        public DbSet<BookCategoryDiscount> BookCategoryDiscounts { get; set; }

        public DbSet<BookOrder> BookOrders { get; set; }

        public DbSet<OrderDetail> OrderDetails { get; set; }

        public DbSet<BookCategory> BookCategories { get; set; }

        public DbSet<SalesTaxConfiguration> SalesTaxConfigurations { get; set; }

        public ObjectContext ObjectContext()
        {
            return (this as IObjectContextAdapter).ObjectContext;
        }


    }
}
