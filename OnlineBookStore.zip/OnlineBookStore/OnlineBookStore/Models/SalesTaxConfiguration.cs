﻿using OnlineBookStore.Repository.Interface;
using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Models
{
    public class SalesTaxConfiguration : IEntity
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public decimal SalesTaxRate { get; set; }

        [Required]
        public DateTime Startdate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        [Required]
        public DateTime CreateDateTime { get; set; }
    }
}
