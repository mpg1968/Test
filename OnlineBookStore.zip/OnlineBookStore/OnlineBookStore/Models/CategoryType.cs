﻿using System.ComponentModel;

namespace OnlineBookStore.Models
{
    public enum CategoryType
    {
        [Description("Crime")]
        Crime,

        [Description("Romance")]
        Romance,

        [Description("Fantasy")]
        Fantasy
    }
}
