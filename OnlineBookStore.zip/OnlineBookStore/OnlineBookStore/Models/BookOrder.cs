﻿using OnlineBookStore.Repository.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Models
{
    public class BookOrder : IEntity
    {
        [Required]
        public int Id { get; set; }
        public int OrderNumber { get; set; }

        public virtual List<OrderDetail> OrderDetails { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }

        public decimal SalesTotal { get; set; }

        public decimal TotalSalesTax
        {
            get
            {
                if (this.SalesTaxRate > 0)
                {
                    return Math.Round(this.SalesTotal * this.SalesTaxRate, 2);
                }

                return 0m;
            }
        }

        public decimal SalesTaxRate { get; set; }

        public decimal TotalCost => Math.Round(this.SalesTotal + this.TotalSalesTax, 2);

        public DateTime CreateDateTime { get; set; }
    }
}
