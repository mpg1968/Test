﻿using OnlineBookStore.Repository.Interface;
using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Models
{
    public class BookCategoryDiscount : IEntity
    {
        [Required]
        public int Id { get; set; }

        public int CategoryType { get; set; }

        public DateTime CreateDateTime { get; set; }

        public decimal Discount { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

    }
}
