﻿using OnlineBookStore.Repository.Implementation;
using OnlineBookStore.Repository.Interface;
using OnlineBookStore.Services.LogicService;
using Unity;

namespace OnlineBookStore
{
    /// <summary>
    /// The class is used to the register DI objects 
    /// </summary>
    public class ConfigureServices
    {
        public static IUnityContainer Container;
        public static void Start()
        {
            Container = new UnityContainer();

            // The In Memory repository 
            // Must be commented out if using the RepositorySqlData
            Container.RegisterType(typeof(IRepository<>), typeof(RepositoryInMemoryData<>));

            // The SQL repository 
            // Must be commented out if using the RepositoryInMemoryData
            //Container.RegisterType(typeof(IRepository<>), typeof(RepositorySqlData<>));

            // The BookOrderLogicService
            Container.RegisterType<IBookOrderLogicService, BookOrderLogicService>();
        }
    }
}
