﻿using OnlineBookStore.Models;
using OnlineBookStore.Repository.Implementation;
using OnlineBookStore.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace OnlineBookStore.Services.LogicService
{
    public class BookOrderLogicService : IBookOrderLogicService
    {
        private readonly IRepository<BookOrder> _repository;
        private readonly IRepository<Book> _bookRepository;
        private readonly IRepository<OrderDetail> _orderDetailRepository;
        private readonly IRepository<BookCategoryDiscount> _categoryRepository;
        private readonly IRepository<BookCategory> _bookCategoryRepository;
        private readonly IRepository<SalesTaxConfiguration> _salesTaxConfigurationRepository;


        private const string SalestaxConfigurationSettingName = "SalesTaxRate";

        /// <summary>
        /// Constructs BookOrderLogicService
        /// </summary>
        /// <param name="repository"></param>
        /// <param name="bookRepository"></param>
        /// <param name="orderDetailRepository"></param>
        /// <param name="categoryRepository"></param>
        /// <param name="bookCategoryRepository"></param>
        /// <param name="salesTaxConfigurationRepository"></param>
        public BookOrderLogicService(IRepository<BookOrder> repository, IRepository<Book> bookRepository,
            IRepository<OrderDetail> orderDetailRepository,
                                     IRepository<BookCategoryDiscount> categoryRepository, IRepository<BookCategory> bookCategoryRepository, IRepository<SalesTaxConfiguration> salesTaxConfigurationRepository)
        {
            _repository = repository;
            _bookRepository = bookRepository;
            _orderDetailRepository = orderDetailRepository;
            _categoryRepository = categoryRepository;
            _bookCategoryRepository = bookCategoryRepository;
            _salesTaxConfigurationRepository = salesTaxConfigurationRepository;
        }

        /// <summary>
        ///  Gets all the booking numbers
        /// </summary>
        /// <param name="includeSalesTax"></param>
        /// <returns>A collection of BookOrders</returns>
        public IEnumerable<BookOrder> GetAllBookOrders(bool includeSalesTax = true)
        {
            try
            {


                var orders = _repository.FindAll();

                foreach (var bookOrder in orders)
                {
                    if (_orderDetailRepository is RepositoryInMemoryData<OrderDetail>)
                    {
                        bookOrder.OrderDetails = GetOrderlinesForOrder(bookOrder.Id);
                    }

                    CalculateOrderItems(bookOrder, includeSalesTax);
                }
                return orders;
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Gets a BookOrder object for a given order number
        /// The include sales tax parameter defaults to true
        /// </summary>
        /// <param name="orderNumber">OrderNumer</param>
        /// <param name="includeSalesTax">Bool</param>
        /// <returns>A BookOrder object</returns>
        public BookOrder GetBookOrderByOrderNumber(int orderNumber, bool includeSalesTax = true)
        {
            try
            {


                var order = _repository.Find(b => b.OrderNumber == orderNumber)?.FirstOrDefault();

                if (order != null)
                {
                    if (_orderDetailRepository is RepositoryInMemoryData<OrderDetail>)
                    {
                        order.OrderDetails = GetOrderlinesForOrder(order.OrderNumber);
                    }

                    order = CalculateOrderItems(order, includeSalesTax);
                }

                return order;
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
                throw;
            }
        }

        #region Private Members

        /// <summary>
        /// Gets the orderlines for a given bookOrderId
        /// </summary>
        /// <param name="bookOrderId"></param>
        /// <returns>A List of OrderDetail objects</returns>
        private List<OrderDetail> GetOrderlinesForOrder(int bookOrderId)
        {
            var results = _orderDetailRepository.Find(o => o.BookOrderId == bookOrderId).ToList();

            foreach (var orderDetail in results)
            {
                orderDetail.Book = GetBookByBookId(orderDetail.BookId);

                if (orderDetail.Book != null)
                {
                    // Get the category discount
                    orderDetail.Book.BookCategory = GetBookCategoryById(orderDetail.Book.BookCategoryId);
                    var categoryId = orderDetail.Book.BookCategoryId;
                    orderDetail.CategoryDiscountPercentage = GetCategoryDiscount(categoryId, orderDetail.CreateDateTime);
                }
            }

            return results;
        }

        /// <summary>
        /// Get a BookCategory object using a bookCategoryId
        /// </summary>
        /// <param name="bookCategoryId"></param>
        /// <returns>BookCategory</returns>
        private BookCategory GetBookCategoryById(int bookCategoryId)
        {
            try
            {
                return _bookCategoryRepository.FindById(bookCategoryId);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Gets a decimal value representing the discount value for a categoryTypeId.
        /// And the create date for the order line occurs within the start and end dates.
        /// </summary>
        /// <param name="categoryTypeId"></param>
        /// <param name="createDate"></param>
        /// <returns>decimal representing the discount for the category</returns>
        private decimal GetCategoryDiscount(int categoryTypeId, DateTime createDate)
        {
            try
            {

                var result = _categoryRepository
                    .Find(c => c.CategoryType == categoryTypeId && c.StartDate <= createDate && c.EndDate >= createDate)
                    ?.FirstOrDefault()
                    ?.Discount;

                return result ?? 0m;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Returns a Book object for a passed BookId
        /// </summary>
        /// <param name="bookId">int</param>
        /// <returns>A Book object</returns>
        private Book GetBookByBookId(int bookId)
        {
            try
            {
                return _bookRepository.FindById(bookId);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        /// <summary>
        /// Sums the value of the orderlines for the order
        /// Using the parameter includeSalesTax it determins if Tax 
        /// should be fetched and used.
        /// </summary>
        /// <param name="order">BookOrder object</param>
        /// <param name="includeSalesTax">Bool</param>
        /// <returns>A BookOrder object</returns>
        private BookOrder CalculateOrderItems(BookOrder order, bool includeSalesTax)
        {
            var orderItem = order;
            var taxRate = 0m;

            if (includeSalesTax)
            {
                taxRate = GetTaxRateFromConfiguration(order.OrderDate);
            }

            orderItem.SalesTaxRate = taxRate;
            var salesOrderTotal = GetSalesOrderTotal(orderItem.OrderDetails);
            orderItem.SalesTotal = Math.Round(salesOrderTotal, 2);
            return orderItem;
        }

        /// <summary>
        /// Sums the value of the orderlines for the order
        /// </summary>
        /// <param name="orderItemOrderDetails">A list of orderDetails</param>
        /// <returns>Decimal represnting the value of the BookOrder (exl Tax)</returns>
        private decimal GetSalesOrderTotal(List<OrderDetail> orderItemOrderDetails)
        {
            var salesOrderTotal = orderItemOrderDetails.Sum(b => b.FinalSellPrice);

            return salesOrderTotal;
        }

        /// <summary>
        /// Gets the Tax rate using the booking date for the order
        /// </summary>
        /// <param name="bookingDate">dateTime</param>
        /// <returns>Returns a decimal representing the sales tax rates</returns>
        private decimal GetTaxRateFromConfiguration(DateTime bookingDate)
        {
            try
            {

                var taxRate = _salesTaxConfigurationRepository
                    .Find(st => st.Startdate <= bookingDate && st.EndDate >= bookingDate).FirstOrDefault()
                    ?.SalesTaxRate;

                return taxRate ?? 0m;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        #endregion

    }
}
