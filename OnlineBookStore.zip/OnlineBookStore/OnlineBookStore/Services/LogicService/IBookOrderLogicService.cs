﻿using OnlineBookStore.Models;
using System.Collections.Generic;

namespace OnlineBookStore.Services.LogicService
{
    /// <summary>
    /// The IBookOrderLogicService interface
    /// </summary>
    public interface IBookOrderLogicService
    {

        /// <summary>
        ///  Gets all the booking numbers
        /// </summary>
        /// <param name="includeSalesTax"></param>
        /// <returns>A collection of BookOrders</returns>
        IEnumerable<BookOrder> GetAllBookOrders(bool includeSalesTax = true);

        /// <summary>
        /// Gets a BookOrder object for a given order number
        /// The include sales tax parameter defaults to true
        /// </summary>
        /// <param name="orderNumber">OrderNumer</param>
        /// <param name="includeSalesTax">Bool</param>
        /// <returns>A BookOrder object</returns>
        BookOrder GetBookOrderByOrderNumber(int orderNumber, bool includeSalesTax = true);
    }
}
