﻿using OnlineBookStore.Models;
using System;
using System.Collections.Generic;

namespace OnlineBookStore.InMemoryTestData
{
    public static class BookStoreInMemoryData
    {
        /// <summary>
        /// Returns a collection of T used for in memory data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>IEnumerable&lt;T&gt;</returns>
        public static IEnumerable<T> CreateInMemoryDataContext<T>()
        where T : class, new()
        {
            return CreateInMemoryData<T>();
        }

        /// <summary>
        /// The name of T is determined. This is used by the switch to determine the data to generate.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        private static IEnumerable<T> CreateInMemoryData<T>() where T : class, new()
        {
            var entityType = typeof(T).Name;

            switch (entityType.ToLower())
            {
                case "book":
                    {
                        return (IEnumerable<T>)GenerateBookData();
                    }
                case "bookcategorydiscount":
                    {
                        return (IEnumerable<T>)GenerateBookCategoryDiscountData();
                    }
                case "bookorder":
                    {
                        return (IEnumerable<T>)GenerateBookOrderData();
                    }
                case "orderdetail":
                    {
                        return (IEnumerable<T>)GenerateOrderLineData();
                    }
                case "bookcategory":
                    {
                        return (IEnumerable<T>)GenerateBookCategoryData();
                    }
                case "salestaxconfiguration":
                    {
                        return (IEnumerable<T>)GenerateSalesTaxConfiguationData();
                    }
            }

            return new List<T>();
        }

        private static IEnumerable<OrderDetail> GenerateOrderLineData()
        {
            var orderDetails = new List<OrderDetail>
            {
               new OrderDetail
                 {
                     Id = 1,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 1,
                     CategoryDiscountPercentage = 0.05m,
                     DiscountValue = 0.54m,
                     FinalSellPrice = 10.44m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 2,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 2,
                     CategoryDiscountPercentage = 0m,
                     DiscountValue = 0m,
                     FinalSellPrice = 2.40m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 3,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 3,
                     CategoryDiscountPercentage = 0m,
                     DiscountValue = 0m,
                     FinalSellPrice = 6.80m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 4,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 4,
                     CategoryDiscountPercentage = 0.05m,
                     DiscountValue = 0.80m,
                     FinalSellPrice = 15.20m,
                     CreateDateTime = DateTime.Now
                 },
                 new OrderDetail
                 {
                     Id = 5,
                     OrderNumber = 1,
                     BookOrderId = 1,
                     BookId = 5,
                     CategoryDiscountPercentage = 0m,
                     DiscountValue = 0m,
                     FinalSellPrice = 22.90m,
                     CreateDateTime = DateTime.Now
                 }
            };

            return orderDetails;
        }

        private static IEnumerable<BookOrder> GenerateBookOrderData()
        {
            var bookOrders = new List<BookOrder>
            {
                new BookOrder {Id = 1,OrderNumber = 1, OrderDetails = null,OrderDate = DateTime.Now,CreateDateTime = DateTime.Now}
            };

            return bookOrders;
        }

        private static IEnumerable<BookCategoryDiscount> GenerateBookCategoryDiscountData()
        {
            var bookCategoryDiscounts = new List<BookCategoryDiscount>
            {
                // Rule - Only sales of the Crime category enjoy a discount of 5%
                new BookCategoryDiscount
                {
                    Id = 1,
                    CategoryType = 1,
                    StartDate = DateTime.Now.AddMonths(-1),
                    EndDate = DateTime.Now.AddMonths(2),
                    CreateDateTime = DateTime.Now,
                    Discount = 0.05m
                },
                new BookCategoryDiscount
                {
                    Id = 2,
                    CategoryType =3,
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now.AddMonths(-2),
                    Discount = 0m,
                    CreateDateTime = DateTime.Now
                },
                new BookCategoryDiscount
                {
                    Id = 3,
                    CategoryType = 2,
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now.AddMonths(-2),
                    Discount = 0m,
                    CreateDateTime = DateTime.Now
                }
            };

            return bookCategoryDiscounts;
        }

        private static IEnumerable<Book> GenerateBookData()
        {
            var bookEntities = new List<Book>
                    {
                        new Book
                        {
                            BookCategoryId = 1,
                            Cost = 10.99m,
                            Id = 1,
                            Name = "Unsolved crimes"
                        },
                        new Book
                        {
                            BookCategoryId = 2,
                            Cost = 2.40m,
                            Id = 2,
                            Name = "A Little Love Story"
                        },
                        new Book
                        {
                            BookCategoryId = 3,
                            Cost = 6.80m,
                            Id = 3,
                            Name = "Heresy"
                        },
                        new Book
                        {
                            BookCategoryId = 1,
                            Cost = 16.00m,
                            Id = 4,
                            Name = "Jack the Ripper"
                        },
                        new Book
                        {
                            BookCategoryId = 3,
                            Cost = 22.90m,
                            Id = 5,
                            Name = "The Tolkien Years"
                        }
                    };
            return bookEntities;
        }

        private static IEnumerable<BookCategory> GenerateBookCategoryData()
        {
            var categories = new List<BookCategory>
            {
                new BookCategory
                {
                    Id = 1,
                    CategoryDescription = "Crime",
                    CreateDateTime = DateTime.Now.AddDays(-2)
                },
                new BookCategory
                {
                    Id = 2,
                    CategoryDescription = "Romance",
                    CreateDateTime = DateTime.Now.AddDays(-2)
                },
                new BookCategory
                {
                    Id = 3,
                    CategoryDescription = "Fantasy",
                    CreateDateTime = DateTime.Now.AddDays(-2)
                }
            };
            return categories;
        }

        private static IEnumerable<SalesTaxConfiguration> GenerateSalesTaxConfiguationData()
        {
            var salesTaxConfig = new List<SalesTaxConfiguration>
            {
                new SalesTaxConfiguration
                {
                    Id = 1,
                    SalesTaxRate = 0.10m,
                    Startdate = new DateTime(2000, 01, 01),
                    EndDate = new DateTime(2030, 01, 01),
                    CreateDateTime = DateTime.Now
                }
            };

            return salesTaxConfig;
        }

    }
}
