﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace OnlineBookStore.Repository.Interface
{
    /// <summary>
    /// A generic interface
    /// </summary>
    /// <typeparam name="T">Must be a class that implements IEntity</typeparam>
    public interface IRepository<T> where T : class, IEntity
    {
        IQueryable<T> FindAll();

        IQueryable<T> Find(Expression<Func<T, bool>> predicate);

        T FindById(int id);
    }
}
