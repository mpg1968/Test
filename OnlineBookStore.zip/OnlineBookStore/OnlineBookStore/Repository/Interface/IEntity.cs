﻿using System;

namespace OnlineBookStore.Repository.Interface
{
    /// <summary>
    /// Interface implemented by the applications models
    /// </summary>
    public interface IEntity
    {
        int Id { get; set; }

        DateTime CreateDateTime { get; set; }
    }
}
