﻿using OnlineBookStore.InMemoryTestData;
using OnlineBookStore.Repository.Interface;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace OnlineBookStore.Repository.Implementation
{
    public class RepositoryInMemoryData<T> : IRepository<T> where T : class, IEntity, new()
    {
        private readonly IQueryable<T> _entities;

        /// <summary>
        /// Constructor sets the local field _entities with a queryable collection of T
        /// using the static method CreateInMemoryDataContext. The data has NO SQL connectivity
        /// and is soley used for test purposes 
        /// </summary>
        public RepositoryInMemoryData()
        {
            _entities = BookStoreInMemoryData.CreateInMemoryDataContext<T>().AsQueryable();
        }

        public IQueryable<T> FindAll()
        {
            return _entities;
        }

        public IQueryable<T> Find(Expression<Func<T, bool>> predicate)
        {
            return _entities.Where(predicate);
        }

        public T FindById(int id)
        {
            return _entities.FirstOrDefault(e => e.Id == id);
        }
    }
}
