﻿using OnlineBookStore.Models;
using OnlineBookStore.Repository.Interface;
using System;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Linq.Expressions;

namespace OnlineBookStore.Repository.Implementation
{
    public class RepositorySqlData<T> : IRepository<T> where T : class, IEntity
    {

        private readonly ObjectSet<T> _context;

        /// <summary>
        /// Constructor calls self with a call to a static method named Create on the 
        /// BookStoreContext
        /// </summary>
        public RepositorySqlData()
         : this(BookStoreContext.Create())
        {

        }

        /// <summary>
        /// Constructor receives a BookStoreContext for each T
        /// An objectSet is set to the local field _context.
        /// 
        /// </summary>
        /// <param name="context">BookStoreContext</param>
        public RepositorySqlData(BookStoreContext context)
        {

            _context = context.ObjectContext().CreateObjectSet<T>();
        }

        /// <summary>
        /// Finds 0 or more objects of T for a given predicate
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns>IQueryable&lt;T&gt;</returns>
        public IQueryable<T> Find(Expression<Func<T, bool>> predicate)
        {
            return _context.Where(predicate);
        }

        /// <summary>
        /// FindAll all objects of T
        /// </summary>
        /// <returns>IQueryable&amp;lt;T&amp;gt;</returns>
        public IQueryable<T> FindAll()
        {
            return _context;
        }

        /// <summary>
        /// FindById an object of T
        /// </summary>
        /// <param name="id">The primary key Id</param>
        /// <returns>T object</returns>
        public T FindById(int id)
        {
            return _context.FirstOrDefault(e => e.Id == id);
        }
    }
}
