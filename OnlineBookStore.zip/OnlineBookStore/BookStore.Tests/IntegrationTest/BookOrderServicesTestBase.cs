﻿using OnlineBookStore.Models;
using OnlineBookStore.Repository.Implementation;
using OnlineBookStore.Services.LogicService;

namespace BookStore.Tests.IntegrationTest
{
    public abstract class BookOrderServicesTestBase
    {
        protected IBookOrderLogicService CreateSut()
        {
            // To test in memory data use the repositories below.
            // And ensure RepositorySqlData objects are commented out

            var bookOrderRepository = new RepositoryInMemoryData<BookOrder>();
            var bookRepository = new RepositoryInMemoryData<Book>();
            var orderDetailRespository = new RepositoryInMemoryData<OrderDetail>();
            var categoryRepository = new RepositoryInMemoryData<BookCategoryDiscount>();
            var bookCategoryRepository = new RepositoryInMemoryData<BookCategory>();
            var salesTaxConfiguration = new RepositoryInMemoryData<SalesTaxConfiguration>();

            // Uncomment to test SQL Repository
            // And ensure RepositoryInMemoryData objects are commented out

            //var bookOrderRepository = new RepositorySqlData<BookOrder>();
            //var bookRepository = new RepositorySqlData<Book>();
            //var orderDetailRespository = new RepositorySqlData<OrderDetail>();
            //var categoryRepository = new RepositorySqlData<BookCategoryDiscount>();
            //var bookCategoryRepository = new RepositorySqlData<BookCategory>();
            //var salesTaxConfiguration = new RepositorySqlData<SalesTaxConfiguration>();


            return new BookOrderLogicService(bookOrderRepository, bookRepository, orderDetailRespository,
                categoryRepository, bookCategoryRepository, salesTaxConfiguration);
        }
    }
}
