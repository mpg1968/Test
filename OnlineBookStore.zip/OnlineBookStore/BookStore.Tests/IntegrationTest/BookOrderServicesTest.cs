﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BookStore.Tests.IntegrationTest
{
    [TestClass]
    public class BookOrderServicesTest : BookOrderServicesTestBase
    {
        /// <summary>
        ///  Tests the a book order for the order number 1 is returned by the service as expected. 
        /// </summary>
        /// <param name="orderNumber">The order number for the book order</param>
        /// <param name="expectedResult">The order number from the expected result</param>
        [DataRow(1, 1)]
        [DataTestMethod]
        public void GetBooksOrderWithOrderNumberReturnsOrder(int orderNumber, int expectedResult)
        {
            // Arrange
            var sut = this.CreateSut();

            // Act
            var result = sut.GetBookOrderByOrderNumber(orderNumber);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedResult, result.OrderNumber);
        }

        /// <summary>
        ///  Tests a NULL result is returned by the service 
        ///  for a non existent order number as expected. 
        /// </summary>
        /// <param name="orderNumber">77</param>
        /// <param name="expectedResult">A NULL value</param>
        [DataRow(77, true)]
        [DataTestMethod]
        public void GetBookOrderWithNonExistentOrderNumberReturnsNull(int orderNumber, bool expectedResult)
        {
            // Arrange
            var sut = this.CreateSut();

            // Act
            var result = sut.GetBookOrderByOrderNumber(orderNumber);

            // Assert            
            Assert.AreEqual(expectedResult, result == null);
        }

        /// <summary>
        ///  The service returns a sales tax rate for the order number
        ///  when the "IncludeSalesTax" value is passed.
        /// </summary>
        /// <param name="orderNumber">1</param>
        /// <param name="includeSalesTax">true</param>
        /// <param name="expectedResult">0.10</param>
        [DataRow(1, true, 0.10)]
        [DataTestMethod]
        public void GetBookOrderWithTaxIncludedReturnsOrderWithSalesTax(int orderNumber, bool includeSalesTax, double expectedResult)
        {
            // Arrange
            var sut = this.CreateSut();

            // Act
            var result = sut.GetBookOrderByOrderNumber(orderNumber, includeSalesTax);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual((decimal)expectedResult, result.SalesTaxRate);
        }

        /// <summary>
        ///  The service returns NO sales tax rate for the order number
        ///  when the "IncludeSalesTax" value of FALSE is passed.
        /// </summary>
        /// <param name="orderNumber">A valid order number</param>
        /// <param name="includeSalesTax">A FALSE value instructing the service not to include sales tax</param>
        /// <param name="expectedResult">0</param>
        [DataRow(1, false, 0)]
        [DataTestMethod]
        public void GetBookOrderWithNoTaxIncludedReturnsOrderWithOutSalesTax(int orderNumber, bool includeSalesTax, int expectedResult)
        {
            // Arrange
            var sut = this.CreateSut();

            // Act
            var result = sut.GetBookOrderByOrderNumber(orderNumber, includeSalesTax);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedResult, result.SalesTaxRate);
        }

        /// <summary>
        ///  The service returns a book order where the total is inclusive of sales tax
        /// </summary>
        /// <param name="orderNumber">order number = 1</param>
        /// <param name="includeSalesTax">True</param>
        /// <param name="expectedResult">63.51</param>
        [DataRow(1, true, 63.51)]
        [DataTestMethod]
        public void GetTotalOrderValueWithSalesTaxExpectedTotalWithTaxIncluded(int orderNumber, bool includeSalesTax,
            double expectedResult)
        {
            // Arrange
            var sut = this.CreateSut();

            // Act
            var result = sut.GetBookOrderByOrderNumber(orderNumber, includeSalesTax);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual((decimal)expectedResult, result.TotalCost);

        }

        /// <summary>
        ///  The service returns a book order where the total is excluding sales tax
        /// </summary>
        /// <param name="orderNumber">1</param>
        /// <param name="includeSalesTax">false</param>
        /// <param name="expectedResult">57.74</param>
        [DataRow(1, false, 57.74)]
        [DataTestMethod]
        public void GetTotalCostWithNoSalesTaxIncludedExpectTotalCostWithoutTax(int orderNumber,
            bool includeSalesTax,
            double expectedResult)
        {
            // Arrange
            var sut = this.CreateSut();

            // Act
            var result = sut.GetBookOrderByOrderNumber(orderNumber, includeSalesTax);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual((decimal)expectedResult, result.TotalCost);
        }
    }
}
